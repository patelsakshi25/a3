const express = require("express");
const session = require("express-session");
const FileStore = require("session-file-store")(session);
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// Session
app.use(
    session({
        store: new FileStore({
            path: "./sessions"
        }),
        secret: "my-secret-key",
        resave: false,
        saveUninitialized: false
    })
);

// Login page
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "login.html"));
});

// Login
app.post("/login", (req, res) => {

    const { username, password } = req.body;

    const users = JSON.parse(
        fs.readFileSync(
            path.join(__dirname, "users.json"),
            "utf8"
        )
    );

    const user = users.find(
        u => u.username === username &&
             u.password === password
    );

    if (!user) {
        return res.send(`
            <h2>Invalid Username or Password</h2>
            <a href="/">Go Back</a>
        `);
    }

    req.session.username = username;

    res.redirect("/dashboard");
});

// Authentication middleware
function checkLogin(req, res, next) {

    if (req.session.username) {
        next();
    } else {
        res.redirect("/");
    }
}

// Protected Route 1
app.get("/dashboard", checkLogin, (req, res) => {

    res.sendFile(
        path.join(__dirname, "views", "dashboard.html")
    );
});

// Protected Route 2
app.get("/profile", checkLogin, (req, res) => {

    res.sendFile(
        path.join(__dirname, "views", "profile.html")
    );
});

// Logout
app.get("/logout", (req, res) => {

    req.session.destroy((err) => {

        if (err) {
            return res.send("Logout Error");
        }

        res.redirect("/");
    });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});