function isAuthenticated(req, res, next) {

    if (req.session.adminId) {
        next();
    } else {
        res.redirect("/");
    }
}

module.exports = isAuthenticated;