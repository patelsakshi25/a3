const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
    service: "gmail",

    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

async function sendEmployeeEmail(
    employeeEmail,
    employeeName,
    empid,
    password
) {

    const mailOptions = {

        from: process.env.EMAIL_USER,

        to: employeeEmail,

        subject: "ERP Employee Account Created",

        html: `
            <h2>Welcome to ERP System</h2>

            <p>Dear ${employeeName},</p>

            <p>Your employee account has been created successfully.</p>

            <h3>Login Details</h3>

            <p>
                <b>Employee ID:</b> ${empid}
            </p>

            <p>
                <b>Password:</b> ${password}
            </p>

            <p>Please keep your login credentials safe.</p>

            <br>

            <p>Regards,<br>ERP Admin</p>
        `
    };

    await transporter.sendMail(mailOptions);
}

module.exports = sendEmployeeEmail;