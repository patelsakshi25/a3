const express = require("express");
const bcrypt = require("bcryptjs");
const Admin = require("../models/Admin");

const router = express.Router();


// LOGIN PAGE
router.get("/", (req, res) => {

    res.render("login", {
        error: null
    });

});


// LOGIN
router.post("/login", async (req, res) => {

    try {

        const { username, password } = req.body;

        const admin = await Admin.findOne({
            username: username
        });

        if (!admin) {

            return res.render("login", {
                error: "Invalid username or password"
            });

        }

        const match = await bcrypt.compare(
            password,
            admin.password
        );

        if (!match) {

            return res.render("login", {
                error: "Invalid username or password"
            });

        }

        req.session.adminId = admin._id;
        req.session.username = admin.username;

        res.redirect("/dashboard");

    } catch (error) {

        console.log(error);

        res.send("Login Error");

    }

});


// LOGOUT
router.get("/logout", (req, res) => {

    req.session.destroy((err) => {

        if (err) {
            return res.send("Logout Error");
        }

        res.redirect("/");

    });

});


module.exports = router;