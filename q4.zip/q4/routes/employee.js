const express = require("express");
const bcrypt = require("bcryptjs");

const Employee = require("../models/Employee");

const generatePassword = require("../utils/generatePassword");
const sendEmployeeEmail = require("../utils/sendEmail");

const router = express.Router();


// EMPLOYEE LIST
router.get("/", async (req, res) => {

    try {

        const employees = await Employee.find();

        res.render("employees", {
            employees
        });

    } catch (error) {

        console.log(error);

        res.send("Error loading employees");

    }

});


// ADD EMPLOYEE PAGE
router.get("/add", (req, res) => {

    res.render("add-employee");

});


// INSERT EMPLOYEE
router.post("/add", async (req, res) => {

    try {

        const {
            name,
            email,
            department,
            designation,
            basicSalary
        } = req.body;


        // Generate Employee ID

        const count = await Employee.countDocuments();

        const empid =
            "EMP" + String(count + 1).padStart(4, "0");


        // Generate Password

        const plainPassword = generatePassword(8);


        // Encrypt password

        const hashedPassword =
            await bcrypt.hash(plainPassword, 10);


        // Salary calculation

        const basic = Number(basicSalary);

        const hra = basic * 0.20;

        const da = basic * 0.10;

        const grossSalary =
            basic + hra + da;

        const pf =
            basic * 0.12;

        const netSalary =
            grossSalary - pf;


        const employee = new Employee({

            empid: empid,

            name: name,

            email: email,

            department: department,

            designation: designation,

            basicSalary: basic,

            hra: hra,

            da: da,

            grossSalary: grossSalary,

            pf: pf,

            netSalary: netSalary,

            password: hashedPassword

        });


        await employee.save();


        // Send Email

        try {

            await sendEmployeeEmail(
                email,
                name,
                empid,
                plainPassword
            );

        } catch (emailError) {

            console.log(
                "Email Error:",
                emailError.message
            );

        }


        res.redirect("/employees");

    } catch (error) {

        console.log(error);

        res.send("Error inserting employee");

    }

});


// EDIT PAGE
router.get("/edit/:id", async (req, res) => {

    try {

        const employee =
            await Employee.findById(req.params.id);

        if (!employee) {
            return res.send("Employee not found");
        }

        res.render("edit-employee", {
            employee
        });

    } catch (error) {

        console.log(error);

        res.send("Error");

    }

});


// UPDATE EMPLOYEE
router.post("/edit/:id", async (req, res) => {

    try {

        const {
            name,
            email,
            department,
            designation,
            basicSalary
        } = req.body;


        const basic = Number(basicSalary);

        const hra = basic * 0.20;

        const da = basic * 0.10;

        const grossSalary =
            basic + hra + da;

        const pf =
            basic * 0.12;

        const netSalary =
            grossSalary - pf;


        await Employee.findByIdAndUpdate(
            req.params.id,
            {

                name,
                email,
                department,
                designation,

                basicSalary: basic,

                hra,

                da,

                grossSalary,

                pf,

                netSalary

            }
        );


        res.redirect("/employees");

    } catch (error) {

        console.log(error);

        res.send("Update Error");

    }

});


// DELETE EMPLOYEE
router.get("/delete/:id", async (req, res) => {

    try {

        await Employee.findByIdAndDelete(
            req.params.id
        );

        res.redirect("/employees");

    } catch (error) {

        console.log(error);

        res.send("Delete Error");

    }

});


module.exports = router;