const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");

const Admin = require("./models/Admin");

const adminRoutes = require("./routes/admin");
const employeeRoutes = require("./routes/employee");

const auth = require("./middleware/auth");

dotenv.config();

const app = express();


// MongoDB Connection

mongoose.connect(process.env.MONGO_URI)
    .then(() => {

        console.log("MongoDB Connected");

    })
    .catch((error) => {

        console.log(
            "MongoDB Connection Error:",
            error
        );

    });


// EJS

app.set("view engine", "ejs");


// Middleware

app.use(express.urlencoded({
    extended: true
}));

app.use(express.json());

app.use(express.static("public"));


// Session

app.use(session({

    secret: process.env.SESSION_SECRET,

    resave: false,

    saveUninitialized: false,

    cookie: {
        maxAge: 1000 * 60 * 60
    }

}));


// Admin Login Routes

app.use("/", adminRoutes);


// Dashboard

app.get("/dashboard", auth, async (req, res) => {

    const Employee =
        require("./models/Employee");

    const count =
        await Employee.countDocuments();

    res.render("dashboard", {

        username: req.session.username,

        employeeCount: count

    });

});


// Employee Routes

app.use(
    "/employees",
    auth,
    employeeRoutes
);


// Server

const PORT =
    process.env.PORT || 3000;

app.listen(PORT, () => {

    console.log(
        `Server running at http://localhost:${PORT}`
    );

});