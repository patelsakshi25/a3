const express = require("express");
const session = require("express-session");
const { createClient } = require("redis");
const { RedisStore } = require("connect-redis");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Redis Client
const redisClient = createClient({
    url: "redis://localhost:6379"
});

redisClient.on("error", (err) => {
    console.log("Redis Error:", err.message);
});

// Connect Redis
async function startServer() {
    try {
        await redisClient.connect();
        console.log("Redis connected successfully");

        // Session configuration
        app.use(
            session({
                store: new RedisStore({
                    client: redisClient,
                    prefix: "myapp:"
                }),
                secret: "mySecretKey123",
                resave: false,
                saveUninitialized: false,
                cookie: {
                    maxAge: 1000 * 60 * 30, // 30 minutes
                    httpOnly: true
                }
            })
        );

        // Login page
        app.get("/", (req, res) => {
            res.sendFile(path.join(__dirname, "public", "login.html"));
        });

        // Login
        app.post("/login", (req, res) => {
            const { username, password } = req.body;

            // Demo login credentials
            if (username === "admin" && password === "12345") {
                req.session.user = {
                    username: username
                };

                res.send(`
                    <h2>Login Successful</h2>
                    <p>Welcome ${username}</p>
                    <a href="/dashboard">Go to Dashboard</a><br>
                    <a href="/profile">Go to Profile</a><br>
                    <a href="/logout">Logout</a>
                `);
            } else {
                res.send(`
                    <h2>Invalid username or password</h2>
                    <a href="/">Try Again</a>
                `);
            }
        });

        // Authentication middleware
        function isAuthenticated(req, res, next) {
            if (req.session.user) {
                next();
            } else {
                res.status(401).send(`
                    <h2>Access Denied</h2>
                    <p>Please login first.</p>
                    <a href="/">Login</a>
                `);
            }
        }

        // Protected Route 1
        app.get("/dashboard", isAuthenticated, (req, res) => {
            res.send(`
                <h1>Dashboard</h1>
                <p>Welcome ${req.session.user.username}</p>
                <p>This is Protected Route 1.</p>

                <a href="/profile">Profile</a><br>
                <a href="/logout">Logout</a>
            `);
        });

        // Protected Route 2
        app.get("/profile", isAuthenticated, (req, res) => {
            res.send(`
                <h1>Profile</h1>
                <p>Username: ${req.session.user.username}</p>
                <p>This is Protected Route 2.</p>

                <a href="/dashboard">Dashboard</a><br>
                <a href="/logout">Logout</a>
            `);
        });

        // Logout
        app.get("/logout", (req, res) => {
            req.session.destroy((err) => {
                if (err) {
                    return res.status(500).send("Logout failed");
                }

                res.clearCookie("connect.sid");

                res.send(`
                    <h2>Logout Successful</h2>
                    <p>You have been logged out.</p>
                    <a href="/">Login Again</a>
                `);
            });
        });

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });

    } catch (error) {
        console.log("Unable to connect to Redis:", error.message);
    }
}

startServer();