const express = require("express");
const path = require("path");

const registrationRouter = require("./routes/registration");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));

// Serve CSS and uploaded files
app.use(express.static(path.join(__dirname, "public")));

app.use("/", registrationRouter);

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});