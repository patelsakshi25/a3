const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");

const {
    body,
    validationResult
} = require("express-validator");

const router = express.Router();


// ===============================
// Create upload folders
// ===============================

const profileDir = path.join(__dirname, "../public/uploads/profile");
const othersDir = path.join(__dirname, "../public/uploads/others");

if (!fs.existsSync(profileDir)) {
    fs.mkdirSync(profileDir, { recursive: true });
}

if (!fs.existsSync(othersDir)) {
    fs.mkdirSync(othersDir, { recursive: true });
}


// ===============================
// Multer Storage
// ===============================

const storage = multer.diskStorage({

    destination: function (req, file, cb) {

        if (file.fieldname === "profilePic") {
            cb(null, profileDir);
        } else {
            cb(null, othersDir);
        }
    },

    filename: function (req, file, cb) {

        const uniqueName =
            Date.now() + "-" +
            Math.round(Math.random() * 100000) +
            path.extname(file.originalname);

        cb(null, uniqueName);
    }
});


// ===============================
// File Validation
// ===============================

const fileFilter = function (req, file, cb) {

    const allowedTypes = [
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/gif"
    ];

    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error("Only JPG, JPEG, PNG and GIF images are allowed."));
    }
};


const upload = multer({
    storage: storage,
    fileFilter: fileFilter,

    limits: {
        fileSize: 2 * 1024 * 1024
    }
});


// ===============================
// GET FORM
// ===============================

router.get("/", (req, res) => {

    res.render("form", {
        errors: [],
        values: {},
        filesError: ""
    });

});


// ===============================
// POST FORM
// ===============================

router.post(
    "/register",

    upload.fields([
        {
            name: "profilePic",
            maxCount: 1
        },
        {
            name: "otherPics",
            maxCount: 5
        }
    ]),

    [

        body("username")
            .trim()
            .notEmpty()
            .withMessage("Username is required.")
            .isLength({ min: 3 })
            .withMessage("Username must contain at least 3 characters."),

        body("password")
            .notEmpty()
            .withMessage("Password is required.")
            .isLength({ min: 6 })
            .withMessage("Password must contain at least 6 characters."),

        body("confirmPassword")
            .notEmpty()
            .withMessage("Confirm password is required.")
            .custom((value, { req }) => {
                if (value !== req.body.password) {
                    throw new Error("Passwords do not match.");
                }

                return true;
            }),

        body("email")
            .trim()
            .notEmpty()
            .withMessage("Email is required.")
            .isEmail()
            .withMessage("Enter a valid email address."),

        body("gender")
            .notEmpty()
            .withMessage("Please select gender.")
            .isIn(["Male", "Female", "Other"])
            .withMessage("Invalid gender."),

        body("hobbies")
            .custom((value) => {

                if (!value) {
                    throw new Error("Please select at least one hobby.");
                }

                return true;
            })

    ],

    (req, res) => {

        const errors = validationResult(req);

        let filesError = "";

        // Profile picture validation
        if (!req.files || !req.files.profilePic) {
            filesError += "Profile picture is required. ";
        }

        // Other pictures validation
        if (!req.files || !req.files.otherPics) {
            filesError += "Please upload at least one other picture.";
        }


        // If validation failed
        if (!errors.isEmpty() || filesError) {

            res.render("form", {

                errors: errors.array(),

                values: req.body,

                filesError: filesError

            });

            return;
        }


        // ===============================
        // Prepare uploaded files
        // ===============================

        const profilePic = req.files.profilePic[0];

        const otherPics = req.files.otherPics;


        // ===============================
        // Display Result
        // ===============================

        res.render("result", {

            data: {

                username: req.body.username,

                email: req.body.email,

                gender: req.body.gender,

                hobbies: Array.isArray(req.body.hobbies)
                    ? req.body.hobbies
                    : [req.body.hobbies],

                profilePic: "/uploads/profile/" + profilePic.filename,

                profilePicName: profilePic.originalname,

                otherPics: otherPics.map(file => ({
                    path: "/uploads/others/" + file.filename,
                    name: file.originalname
                }))

            }

        });

    }
);


// ===============================
// Download Profile Picture
// ===============================

router.get("/download/profile/:filename", (req, res) => {

    const filePath = path.join(
        profileDir,
        req.params.filename
    );

    if (fs.existsSync(filePath)) {

        res.download(filePath);

    } else {

        res.status(404).send("File not found.");

    }

});


// ===============================
// Download Other Picture
// ===============================

router.get("/download/other/:filename", (req, res) => {

    const filePath = path.join(
        othersDir,
        req.params.filename
    );

    if (fs.existsSync(filePath)) {

        res.download(filePath);

    } else {

        res.status(404).send("File not found.");

    }

});


module.exports = router;